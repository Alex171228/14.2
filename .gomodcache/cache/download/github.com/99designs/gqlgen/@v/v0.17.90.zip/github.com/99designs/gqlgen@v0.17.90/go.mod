module github.com/99designs/gqlgen

go 1.25.0

require (
	github.com/PuerkitoBio/goquery v1.12.0
	github.com/go-viper/mapstructure/v2 v2.5.0
	github.com/goccy/go-yaml v1.19.2
	github.com/google/uuid v1.6.0
	github.com/gorilla/websocket v1.5.0 // do not upgrade to v1.5.1 as it has serious bugs
	github.com/hashicorp/golang-lru/v2 v2.0.7
	github.com/logrusorgru/aurora/v4 v4.0.0
	github.com/matryer/moq v0.6.0
	github.com/mattn/go-colorable v0.1.14
	github.com/mattn/go-isatty v0.0.21
	github.com/sosodev/duration v1.4.0
	github.com/stretchr/testify v1.11.1
	github.com/urfave/cli/v3 v3.8.0
	github.com/vektah/gqlparser/v2 v2.5.33
	golang.org/x/text v0.35.0
	golang.org/x/tools v0.42.0
	google.golang.org/protobuf v1.36.11
)

require golang.org/x/sync v0.20.0

require (
	github.com/agnivade/levenshtein v1.2.1 // indirect
	github.com/andybalholm/cascadia v1.3.3 // indirect
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	golang.org/x/mod v0.33.0 // indirect
	golang.org/x/net v0.52.0 // indirect
	golang.org/x/sys v0.42.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
